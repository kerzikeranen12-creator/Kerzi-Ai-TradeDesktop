# AI Trading Desk v3

Autonomous crypto discovery + six-agent paper decision desk. v1 rules are preserved: paper-only, no leverage, max loss 0.25% of paper balance, min RR 2:1, TITAN veto, NOVA TRADE/WAIT/REJECT, human review, journal, and no invented market data.

## What v3 adds
- Autonomous Solana candidate discovery from DEX Screener.
- Exact token/pool discovery through GeckoTerminal; no guessed DEX pair mapping.
- 15-minute OHLCV technical analysis with EMA9/EMA21, RSI14, ATR14, support/resistance and volume confirmation.
- Deterministic LONG setup builder from observed levels.
- Risk sizing with 0.25% max-loss rule and liquidity/portfolio caps.
- Conservative modeled slippage + fees and adjusted RR.
- Optional GoPlus Solana security gate; fail-closed if enabled but unavailable.
- News RSS adapter and sentiment/hype heuristics.
- Six-agent decision chain and JSONL journal.
- Paper state and a Streamlit dashboard.
- Scheduler for autonomous repeated scans.

## Run on Windows
1. Install Python 3.11+.
2. Open PowerShell in this folder.
3. `py -m venv .venv`
4. `.venv\\Scripts\\Activate.ps1`
5. `pip install -r requirements.txt`
6. `python SELF_TEST.py`
7. `python run.py`
8. Dashboard: `streamlit run dashboard.py`
9. Continuous scanner: `python scheduler.py`

## Optional security key
Set `GOPLUS_API_KEY` as an environment variable. Never put wallet seeds/private keys or exchange credentials in the project. If GoPlus is enabled and the key is absent, the security gate fails closed and NOVA cannot approve a trade.

## Important
This is an autonomous *research and paper-trading* system. It does not contain live order execution, wallet signing, exchange credentials, or a mechanism to move real money. A TRADE result is a paper decision requiring human review.
