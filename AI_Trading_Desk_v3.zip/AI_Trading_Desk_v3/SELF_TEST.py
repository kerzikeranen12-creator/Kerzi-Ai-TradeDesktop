from technical import analyze
from setup import build_long_setup
from risk import size
rows=[]; p=100.0
for i in range(100):
 p*=1.001
 rows.append([i,p-.5,p+1,p-1,p,1000+i*2])
t=analyze(rows,{'ema_fast':9,'ema_slow':21,'rsi_period':14,'atr_period':14,'min_candles':60})
assert t['verdict']=='BULLISH'
s=build_long_setup(t); assert s['status']=='OK' and s['rr']>=2
r=size(10000,s['entry'],s['stop'],100000,{'max_loss_pct_balance':.25,'max_position_pct_balance':10,'max_position_pct_liquidity':1})
assert r['status']=='PASS'
print('SELF_TEST OK')
