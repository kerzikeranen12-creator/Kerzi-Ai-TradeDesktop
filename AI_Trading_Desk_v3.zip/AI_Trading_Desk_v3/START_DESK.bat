@echo off
cd /d %~dp0
if not exist .venv py -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt
python SELF_TEST.py
python run.py
pause
