def atlas(cands): return {'verdict':'WATCH' if cands else 'SKIP','ranked':[(c['symbol'],c['score']) for c in cands]}
def vega(t): return {'verdict':t.get('verdict','NEED MORE DATA'),'evidence':t}
def orion(items): return {'verdict':items.get('verdict','NEED MORE DATA'),'items':items.get('items',[])}
def luna(c):
    buys=c.get('buys_1h',0); sells=c.get('sells_1h',0); ratio=buys/max(1,sells)
    return {'verdict':'HYPE-DRIVEN' if ratio>3 else 'BULLISH' if ratio>1.2 else 'BEARISH' if ratio<.8 else 'MIXED','buy_sell_ratio':ratio}
def titan(setup,risk,security,tech,rr):
    checks={'setup':setup.get('status')=='OK','risk':risk.get('status')=='PASS','security':security.get('status')=='OK' and not security.get('hard_fail',True),'technical':tech.get('verdict')=='BULLISH','rr':rr>=2}
    return {'final_verdict':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'rr':rr}
def nova(atlas_r,vega_r,orion_r,luna_r,titan_r,setup):
    if titan_r['final_verdict']!='PASS': return {'final_decision':'REJECT','reason':'TITAN veto','setup':setup}
    if vega_r['verdict']=='BULLISH' and setup.get('status')=='OK': return {'final_decision':'TRADE','direction':'LONG','setup':setup}
    return {'final_decision':'WAIT','reason':'confirmation required','setup':setup}
