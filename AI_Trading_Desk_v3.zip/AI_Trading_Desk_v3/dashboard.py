import json,streamlit as st
from pathlib import Path
st.set_page_config(page_title='AI Trading Desk',layout='wide')
st.title('AI Trading Desk — Paper Trading')
p=Path('data/runs_latest.json')
if not p.exists(): st.info('Run python engine.py first.'); st.stop()
runs=json.loads(p.read_text())
cols=st.columns(4); cols[0].metric('Candidates',len(runs)); cols[1].metric('TRADE',sum(r['NOVA']['final_decision']=='TRADE' for r in runs)); cols[2].metric('WAIT',sum(r['NOVA']['final_decision']=='WAIT' for r in runs)); cols[3].metric('REJECT',sum(r['NOVA']['final_decision']=='REJECT' for r in runs))
rows=[]
for r in runs:
 c=r['candidate']; rows.append({'symbol':c['symbol'],'score':c['score'],'market_cap':c['market_cap'],'liquidity':c['liquidity_usd'],'24h_volume':c['volume_24h'],'tech':r['technical']['verdict'],'security':r['security']['status'],'RR':r['adjusted_rr'],'NOVA':r['NOVA']['final_decision']})
st.dataframe(rows,use_container_width=True)
st.caption('Data sources: DEX Screener + GeckoTerminal; security gate optionally GoPlus. No live orders.')
