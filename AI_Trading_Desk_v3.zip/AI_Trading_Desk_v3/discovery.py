from sources import dex_profiles,dex_boosts,dex_token_pairs,f

def best_pair(pairs, quote_symbols):
    eligible=[]
    for p in pairs or []:
        q=(p.get('quoteToken') or {}).get('symbol','').upper()
        if not quote_symbols or q in quote_symbols: eligible.append(p)
    return max(eligible or (pairs or []), key=lambda p:f((p.get('liquidity') or {}).get('usd')))

def score(p):
    liq=f((p.get('liquidity') or {}).get('usd')); vol=f((p.get('volume') or {}).get('h24'))
    ch=p.get('priceChange') or {}; c1=f(ch.get('h1')); c6=f(ch.get('h6')); c24=f(ch.get('h24'))
    tx=(p.get('txns') or {}).get('h1') or {}; b=f(tx.get('buys')); s=f(tx.get('sells')); total=b+s
    x=0
    x+=max(-10,min(25,c1))*1.2 + max(-10,min(40,c6))*.4 + max(-20,min(100,c24))*.12
    if total>=20: x+=max(-10,min(10,(b-s)/total*10))
    x+=12 if liq>=100000 else 8 if liq>=50000 else 4 if liq>=20000 else 0
    x+=12 if vol>=1000000 else 8 if vol>=250000 else 4 if vol>=50000 else 0
    x+=min(5,(p.get('boosts') or {}).get('active',0) or 0)
    if c1>50: x-=25
    if c24>250: x-=20
    return round(max(0,min(100,x)),2)

def discover(h, chain, cfg):
    addresses=[]
    for src in (dex_profiles(h), dex_boosts(h)):
        for x in src if isinstance(src,list) else []:
            if x.get('chainId')==chain and x.get('tokenAddress'): addresses.append(x['tokenAddress'])
    seen=set(); out=[]
    for a in addresses:
        if a in seen: continue
        seen.add(a)
        try: pairs=dex_token_pairs(h,chain,a)
        except Exception: continue
        p=best_pair(pairs,cfg.get('quote_symbols',[]))
        if not p: continue
        liq=f((p.get('liquidity') or {}).get('usd')); vol=f((p.get('volume') or {}).get('h24')); mc=f(p.get('marketCap') or p.get('fdv'))
        ch=p.get('priceChange') or {}; c1=f(ch.get('h1')); c24=f(ch.get('h24'))
        if liq<cfg['min_liquidity_usd'] or vol<cfg['min_volume_24h_usd'] or mc<cfg['min_market_cap_usd']: continue
        if cfg.get('max_market_cap_usd') and mc>cfg['max_market_cap_usd']: continue
        if c1>cfg['max_1h_pump_pct'] or c24>cfg['max_24h_pump_pct']: continue
        out.append({'chain':chain,'token_address':a,'symbol':(p.get('baseToken') or {}).get('symbol'),'name':(p.get('baseToken') or {}).get('name'),'pair_address':p.get('pairAddress'),'dex':p.get('dexId'),'url':p.get('url'),'price_usd':f(p.get('priceUsd')),'market_cap':mc,'fdv':f(p.get('fdv')),'liquidity_usd':liq,'volume_24h':vol,'volume_1h':f((p.get('volume') or {}).get('h1')),'change_1h':c1,'change_6h':f(ch.get('h6')),'change_24h':c24,'buys_1h':f(((p.get('txns') or {}).get('h1') or {}).get('buys')),'sells_1h':f(((p.get('txns') or {}).get('h1') or {}).get('sells')),'boosts':(p.get('boosts') or {}).get('active',0) or 0,'created_at':p.get('pairCreatedAt'),'info':p.get('info') or {},'score':score(p)})
    return sorted(out,key=lambda x:x['score'],reverse=True)[:cfg.get('candidate_limit',25)]
