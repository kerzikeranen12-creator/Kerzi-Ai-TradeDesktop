import json,os,time
from pathlib import Path
from datetime import datetime,timezone
from sources import Http,gecko_network,gecko_pool_search,gecko_ohlcv,f
from discovery import discover
from technical import analyze
from setup import build_long_setup
from risk import size,slippage_bps,adjusted_rr
from security import assess
from news import fetch,verdict
from agents import atlas,vega,orion,luna,titan,nova
from journal import Journal

def map_pool(h,network,token,pair_address):
    pools=gecko_pool_search(h,network,token)
    # Gecko pool data exposes pool address in id like network_pooladdress; match exact suffix.
    for p in pools:
        pid=p.get('id',''); attrs=p.get('attributes') or {}; addr=pid.split('_',1)[1] if '_' in pid else ''
        if addr==pair_address or attrs.get('address')==pair_address: return pid
    return None

def scan_once(cfg):
    h=Http(); chain=cfg['chain']; dc=cfg['discovery']; candidates=discover(h,chain,dc)
    net=gecko_network(h,chain); runs=[]
    for c in candidates:
        security=assess(h,c['token_address'],cfg['security'])
        news_items=fetch(c.get('symbol',''),cfg['news']['feeds'],cfg['news']['max_items']) if cfg['news']['enabled'] else []
        news={'items':news_items,'verdict':verdict(news_items)}
        tf='15m'; tech={'verdict':'NEED MORE DATA'}; pool_id=None
        try:
            pool_id=map_pool(h,net,c['token_address'],c['pair_address'])
            if pool_id:
                rows=gecko_ohlcv(h,net,pool_id,'minute',15,cfg['technical']['lookback'])
                tech=analyze(rows,cfg['technical'])
        except Exception as e: tech={'verdict':'NEED MORE DATA','reason':str(e)}
        setup=build_long_setup(tech)
        rr=setup.get('rr',0) if setup.get('status')=='OK' else 0
        risk=size(cfg['risk']['paper_balance_usd'],setup.get('entry',0),setup.get('stop',0),c['liquidity_usd'],cfg['risk']) if setup.get('status')=='OK' else {'status':'FAIL','reason':'no valid setup'}
        slip=slippage_bps(risk.get('notional',0),c['liquidity_usd'],cfg['risk']) if risk.get('status')=='PASS' else 0
        adj_rr=adjusted_rr(setup['entry'],setup['stop'],setup['target'],slip,slip,cfg['risk']['fee_bps']) if setup.get('status')=='OK' else 0
        a=atlas([c]); v=vega(tech); o=orion(news); l=luna(c); t=titan(setup,risk,security,tech,adj_rr); n=nova(a,v,o,l,t,setup)
        rec={'decision_id':datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+(c.get('symbol') or 'UNKNOWN'),'timestamp':datetime.now(timezone.utc).isoformat(),'candidate':c,'pool_id':pool_id,'technical':tech,'security':security,'news':news,'setup':setup,'risk':risk,'slippage_bps_estimate':slip,'adjusted_rr':adj_rr,'ATLAS':a,'VEGA':v,'ORION':o,'LUNA':l,'TITAN':t,'NOVA':n,'paper_only':True}
        Journal().append(rec); runs.append(rec)
    Path('data/candidates_latest.json').write_text(json.dumps(candidates,indent=2,ensure_ascii=False)); Path('data/runs_latest.json').write_text(json.dumps(runs,indent=2,ensure_ascii=False)); return runs

def main():
    cfg=json.loads(Path('config.json').read_text()); runs=scan_once(cfg)
    print('AI TRADING DESK v3 — PAPER ONLY')
    for r in runs[:15]: print(f"{r['candidate']['symbol']:>12} score={r['candidate']['score']:>5} tech={r['technical']['verdict']:<15} sec={r['security']['status']:<12} NOVA={r['NOVA']['final_decision']}")
    print('Decisions saved to data/decisions.jsonl')
if __name__=='__main__': main()
