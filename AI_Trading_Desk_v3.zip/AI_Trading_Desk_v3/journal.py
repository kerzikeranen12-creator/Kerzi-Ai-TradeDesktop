import json
from pathlib import Path
class Journal:
    def __init__(self,path='data/decisions.jsonl'): self.path=Path(path); self.path.parent.mkdir(exist_ok=True)
    def append(self,record):
        with self.path.open('a',encoding='utf-8') as f: f.write(json.dumps(record,ensure_ascii=False)+'\n')
