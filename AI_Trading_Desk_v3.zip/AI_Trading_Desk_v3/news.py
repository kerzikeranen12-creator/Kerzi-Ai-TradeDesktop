import feedparser,re

def fetch(symbol,feeds,max_items=20):
    out=[]; sym=(symbol or '').lower()
    for url in feeds:
        try:
            f=feedparser.parse(url)
            for e in f.entries[:max_items]:
                title=e.get('title',''); text=(title+' '+e.get('summary','')).lower()
                if sym and sym not in text: continue
                out.append({'title':title,'url':e.get('link'),'published':e.get('published'),'source':url})
        except Exception: pass
    return out[:max_items]

def verdict(items):
    if not items: return 'NEED MORE DATA'
    pos=['partnership','listing','launch','integrat','adoption','approval','bullish']; neg=['hack','exploit','scam','rug','lawsuit','ban','attack']
    p=n=0
    for x in items:
        t=x['title'].lower(); p+=sum(w in t for w in pos); n+=sum(w in t for w in neg)
    return 'BULLISH' if p>n else 'BEARISH' if n>p else 'MIXED'
