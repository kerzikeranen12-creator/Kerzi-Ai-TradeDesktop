import json
from pathlib import Path
from datetime import datetime,timezone
class Paper:
    def __init__(self,path='data/paper_state.json',balance=10000):
        self.path=Path(path); self.path.parent.mkdir(exist_ok=True)
        if self.path.exists(): self.s=json.loads(self.path.read_text())
        else: self.s={'balance':balance,'open':None,'history':[]}
    def save(self): self.path.write_text(json.dumps(self.s,indent=2))
    def open_trade(self,rec):
        if self.s['open']: return False,'open idea already exists'
        self.s['open']={'opened_at':datetime.now(timezone.utc).isoformat(),'trade':rec}; self.save(); return True,'opened'
    def mark(self,price):
        o=self.s.get('open')
        if not o:return None
        t=o['trade']; entry=t['entry']; stop=t['stop']; target=t['target']
        if price<=stop: return self.close(price,'STOP')
        if price>=target:return self.close(price,'TARGET')
        return None
    def close(self,price,reason):
        t=self.s['open']['trade']; pnl=(price-t['entry'])*t['quantity']; self.s['balance']+=pnl
        out={'closed_at':datetime.now(timezone.utc).isoformat(),'exit':price,'reason':reason,'pnl':pnl,'trade':t}; self.s['history'].append(out); self.s['open']=None; self.save(); return out
