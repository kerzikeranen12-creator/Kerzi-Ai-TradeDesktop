def size(balance, entry, stop, liquidity, cfg):
    max_loss=balance*cfg['max_loss_pct_balance']/100
    per_unit=entry-stop
    if per_unit<=0: return {'status':'FAIL','reason':'invalid risk per unit'}
    qty=max_loss/per_unit; notional=qty*entry
    cap=min(balance*cfg['max_position_pct_balance']/100, liquidity*cfg['max_position_pct_liquidity']/100)
    if notional>cap: qty=cap/entry; notional=cap
    modeled_loss=qty*per_unit
    return {'status':'PASS' if modeled_loss<=max_loss+1e-9 else 'FAIL','max_loss':max_loss,'quantity':qty,'notional':notional,'modeled_loss':modeled_loss}

def slippage_bps(notional, liquidity, cfg):
    base=cfg['slippage_bps_base']; extra=cfg['slippage_bps_liquidity_factor']*(notional/max(liquidity,1))
    return max(0,base+extra)

def adjusted_rr(entry,stop,target,entry_bps,exit_bps,fee_bps):
    e=entry*(1+entry_bps/10000); s=stop*(1-entry_bps/10000); t=target*(1-exit_bps/10000)
    reward=max(0,t-e)-e*fee_bps/10000; risk=max(0,e-s)+e*fee_bps/10000
    return reward/risk if risk else 0
