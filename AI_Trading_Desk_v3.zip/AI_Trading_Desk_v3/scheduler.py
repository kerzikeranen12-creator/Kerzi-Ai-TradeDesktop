import json,time
from pathlib import Path
from engine import scan_once
cfg=json.loads(Path('config.json').read_text())
print('Scheduler started. Paper-only. Ctrl+C to stop.')
while True:
    try: scan_once(cfg)
    except Exception as e: print('scan error:',e)
    time.sleep(cfg.get('scan_interval_seconds',300))
