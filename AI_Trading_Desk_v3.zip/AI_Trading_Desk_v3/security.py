from sources import goplus_security

def assess(h, token, cfg):
    if not cfg.get('enabled',True): return {'status':'DISABLED','verdict':'NEUTRAL','checks':[]}
    import os
    key=os.getenv(cfg.get('goplus_api_key_env','GOPLUS_API_KEY'))
    raw=goplus_security(h,token,key)
    if raw.get('status')!='OK': return {'status':'UNAVAILABLE','verdict':'NEED MORE DATA','hard_fail':cfg.get('fail_closed',True),'reason':raw.get('reason')}
    d=raw.get('data') or {}; checks=[]; hard=False
    def flag(name,bad,reason):
        nonlocal hard; checks.append({'name':name,'pass':not bad,'reason':reason}); hard=hard or bad
    flag('honeypot',str(d.get('is_honeypot','0'))=='1','honeypot detected')
    flag('cannot_sell',str(d.get('cannot_sell','0'))=='1','cannot sell')
    flag('sell_tax',float(d.get('sell_tax') or 0)*100>cfg['max_sell_tax_pct'],'sell tax above limit')
    flag('buy_tax',float(d.get('buy_tax') or 0)*100>cfg['max_buy_tax_pct'],'buy tax above limit')
    top10=0
    for hld in d.get('holders') or []:
        try: top10+=float(hld.get('percent') or 0)*100
        except: pass
    flag('top10_concentration',top10>cfg['max_top10_pct'],'top10 concentration above limit')
    return {'status':'OK','verdict':'BEARISH' if hard else 'BULLISH','hard_fail':hard,'top10_pct':top10,'checks':checks,'raw_selected':{k:d.get(k) for k in ['is_honeypot','cannot_sell','sell_tax','buy_tax','is_mintable','is_in_dex','holder_count','is_locked','locked_detail']}}
