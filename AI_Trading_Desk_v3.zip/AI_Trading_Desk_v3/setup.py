def build_long_setup(t):
    if t.get('verdict')!='BULLISH': return {'status':'REJECT','reason':'technical trend not bullish'}
    e=t.get('close'); s=t.get('support'); r=t.get('resistance'); atr=t.get('atr') or 0
    if not all(isinstance(v,(int,float)) and v>0 for v in [e,s,r]): return {'status':'REJECT','reason':'missing levels'}
    # Conservative observed-level geometry: stop below observed support, target above observed resistance.
    stop=min(s, e-1.0*atr) if atr else s
    if stop>=e: return {'status':'REJECT','reason':'invalid stop geometry'}
    target=max(r, e+2*(e-stop))
    rr=(target-e)/(e-stop)
    if rr<2: return {'status':'REJECT','reason':'RR below 2'}
    return {'status':'OK','direction':'LONG','entry':e,'stop':stop,'target':target,'rr':rr,'invalidation':'close below stop/support'}
