import os, time, requests
from datetime import datetime, timezone

DEX='https://api.dexscreener.com'
GECKO='https://api.geckoterminal.com/api/v2'
GOPLUS='https://api.gopluslabs.io/api/v1/solana/token_security'

class Http:
    def __init__(self, timeout=15): self.timeout=timeout
    def get_json(self, url, params=None, headers=None):
        r=requests.get(url, params=params, headers=headers, timeout=self.timeout)
        r.raise_for_status(); return r.json()

def utc_now(): return datetime.now(timezone.utc).isoformat()
def f(x, d=0.0):
    try: return float(x)
    except: return d

def dex_profiles(h): return h.get_json(DEX+'/token-profiles/latest/v1')
def dex_boosts(h): return h.get_json(DEX+'/token-boosts/latest/v1')
def dex_token_pairs(h, chain, address): return h.get_json(f'{DEX}/token-pairs/v1/{chain}/{address}')
def dex_pair(h, chain, pair): return (h.get_json(f'{DEX}/latest/dex/pairs/{chain}/{pair}').get('pairs') or [None])[0]

def gecko_network(h, chain='solana'):
    data=h.get_json(GECKO+'/networks')
    for x in data.get('data',[]):
        a=x.get('attributes') or {}
        if a.get('identifier')==chain or a.get('name','').lower()==chain.lower(): return x.get('id')
    return chain

def gecko_pool_search(h, network, token):
    # Exact token-address pool discovery; no guessed pair->pool mapping.
    data=h.get_json(f'{GECKO}/networks/{network}/tokens/{token}/pools', params={'page':1})
    return data.get('data') or []

def gecko_ohlcv(h, network, pool_id, timeframe='minute', aggregate=5, limit=120):
    params={'limit':limit,'currency':'usd','token':'base'}
    path=f'{GECKO}/networks/{network}/pools/{pool_id}/ohlcv/{timeframe}'
    params['aggregate']=aggregate
    data=h.get_json(path, params=params)
    rows=((data.get('data') or {}).get('attributes') or {}).get('ohlcv_list') or []
    # Gecko returns [timestamp, open, high, low, close, volume]
    return rows

def goplus_security(h, token, api_key):
    if not api_key: return {'status':'UNAVAILABLE','reason':'GOPLUS_API_KEY not set'}
    headers={'Authorization':f'Bearer {api_key}'}
    data=h.get_json(GOPLUS, params={'contract_addresses':token}, headers=headers)
    result=data.get('result') or {}
    if isinstance(result, dict) and token in result: result=result[token]
    return {'status':'OK','data':result}
