import numpy as np, pandas as pd

def frame(rows):
    if not rows: return None
    df=pd.DataFrame(rows,columns=['ts','open','high','low','close','volume'])
    for c in ['open','high','low','close','volume']: df[c]=pd.to_numeric(df[c],errors='coerce')
    return df.dropna().sort_values('ts').reset_index(drop=True)

def indicators(df, ema_fast=9, ema_slow=21, rsi_n=14, atr_n=14):
    x=df.copy(); x['ema_fast']=x.close.ewm(span=ema_fast,adjust=False).mean(); x['ema_slow']=x.close.ewm(span=ema_slow,adjust=False).mean()
    d=x.close.diff(); gain=d.clip(lower=0).rolling(rsi_n).mean(); loss=(-d.clip(upper=0)).rolling(rsi_n).mean(); rs=gain/loss.replace(0,np.nan); x['rsi']=100-(100/(1+rs))
    prev=x.close.shift(1); tr=pd.concat([(x.high-x.low),(x.high-prev).abs(),(x.low-prev).abs()],axis=1).max(axis=1); x['atr']=tr.rolling(atr_n).mean()
    x['vol_ma']=x.volume.rolling(20).mean(); return x

def analyze(rows, cfg):
    df=frame(rows)
    if df is None or len(df)<cfg.get('min_candles',60): return {'verdict':'NEED MORE DATA','reason':'insufficient OHLCV'}
    x=indicators(df,cfg['ema_fast'],cfg['ema_slow'],cfg['rsi_period'],cfg['atr_period']); z=x.iloc[-1]; prev=x.iloc[-2]
    highs=x.high.iloc[-20:-1]; lows=x.low.iloc[-20:-1]
    resistance=float(highs.max()); support=float(lows.min()); close=float(z.close); atr=float(z.atr) if np.isfinite(z.atr) else 0
    trend='BULLISH' if z.ema_fast>z.ema_slow and close>z.ema_slow else 'BEARISH' if z.ema_fast<z.ema_slow and close<z.ema_slow else 'NEUTRAL'
    breakout=close>resistance and prev.close<=resistance; breakdown=close<support and prev.close>=support
    volume_confirm=bool(np.isfinite(z.vol_ma) and z.volume>z.vol_ma*1.2)
    return {'verdict':trend,'close':close,'support':support,'resistance':resistance,'ema_fast':float(z.ema_fast),'ema_slow':float(z.ema_slow),'rsi':float(z.rsi) if np.isfinite(z.rsi) else None,'atr':atr,'volume':float(z.volume),'volume_ma20':float(z.vol_ma) if np.isfinite(z.vol_ma) else None,'breakout':bool(breakout),'breakdown':bool(breakdown),'volume_confirm':volume_confirm,'candles':len(x)}
